import React from "react";
import { useState } from "react";
import "../App.css"

export const Login  =  () =>{

    
 
    const [user,setuser] = useState("")
    const [pass,setpass] = useState("")
    const [err,seterr] = useState("")


    const form =(event) =>{
        seterr("")
       event.preventDefault();
        
       if(user === "" || pass === "") seterr("please enter valid detals")
        else{
            console.log("username :",user)
            console.log("password :",pass)
        } 
        

    }
    


    

    return (
        <>
        <br/>

        
       
            
        
        <h1>Sign up</h1>
        <br></br>
        <form onSubmit = {form}>
           <input placeholder = "username" onChange = {(e) => setuser(e.target.value)}></input>
           <input placeholder = "password" onChange = {(e) =>setpass(e.target.value)}></input>
           <button >submit</button>
           <div id = "err">{err}</div>

        </form>

        </>
    )
}

